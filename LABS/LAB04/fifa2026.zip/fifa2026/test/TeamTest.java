package test;
import domain.*;


import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TeamTest{
   
 
    @Test
    public void shouldCalculateTheMarketValueOfATeam(){                              
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ", 690,'A',760000000,"Bayer"));
        t.addPlayer(new Player("JAMES", 516,'M',2200000,"Minnesota"));
        t.addPlayer(new Player("BORRE", 445,'A',4400000,"Sport Club"));
        t.addPlayer(new Player("LUCUMI", 1250,'D',125000000,"Bologna"));
        t.addPlayer(new Player("VARGAS", 1160,'P',540000,"Atlas"));
        try {
           assertEquals(168522432,t.marketValue());
        } catch (FifaException e){
            fail("Threw a exception"); 
        }    
    }    

    @Test
    public void shouldThrowExceptionIfTeamHasNoPlayer(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");

        
        try { 
           int value=t.marketValue();
           fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.IMPOSSIBLE,e.getMessage());
        }    
    }     
    
    
    @Test
    public void shouldThrowExceptionIfPlayersMinutesSumZero(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ",0,'A',760000000,"Bayer"));
        t.addPlayer(new Player("JAMES", 0,'M',2200000,"Minnesota"));
        t.addPlayer(new Player("BORRE", 0,'A',4400000,"Sport Club"));
        t.addPlayer(new Player("LUCUMI", 0,'D',125000000,"Bologna"));
        t.addPlayer(new Player("VARGAS", 0,'P',540000,"Atlas"));
        try { 
           int value=t.marketValue();
           fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.IMPOSSIBLE,e.getMessage());
        }    
    } 
    
   @Test
    public void shouldThrowExceptionIfAMarketValueIsNotKnown(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ", 690,'A',760000000,"Bayer"));
        t.addPlayer(new Player("JAMES", 516,'M',null,"Minnesota"));
        t.addPlayer(new Player("BORRE", 445,'A',4400000,"Sport Club"));
        t.addPlayer(new Player("LUCUMI", 1250,'D',125000000,"Bologna"));
        t.addPlayer(new Player("VARGAS", 1160,'P',540000,"Atlas"));
        try { 
           int value=t.marketValue();
           fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.VALUE_UNKNOWN,e.getMessage());
        }    
    }     
    
   @Test
    public void shouldThrowExceptionIfAMinutesIsNotKnown(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ", 690,'A',0,"Bayer"));
        t.addPlayer(new Player("JAMES", 516,'M',0,"Minnesota"));
        t.addPlayer(new Player("BORRE", 445,'A',0,"Sport Club"));
        t.addPlayer(new Player("LUCUMI", 1250,'D',0,"Bologna"));
        t.addPlayer(new Player("VARGAS", null,'P',0,"Atlas"));
        try { 
           int value=t.marketValue();
           fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.MINUTES_UNKNOWN,e.getMessage());
        }    
    }  

    @Test
    public void shouldCalculateDefatulMarketValue(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ", 690,'A',760000000,"Bayer"));
        t.addPlayer(new Player("JAMES", null,'M',2200000,"Minnesota"));
        t.addPlayer(new Player("BORRE", 445,'A',null,"Sport Club"));
        t.addPlayer(new Player("LUCUMI", 1250,'D',125000000,"Bologna"));
        t.addPlayer(new Player("VARGAS", null,'P',null,"Atlas"));
        try { 
           int value=t.defaultMarkedValue(1000000, 1000);
           assertEquals(156053591, value);
        } catch (FifaException e) {
            fail("threw an exception");
        }
    }
    
    @Test
    public void shouldThrowExceptionIfPlayersNotHasMinutes(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ",0,'A',760000000,"Bayer"));
        t.addPlayer(new Player("JAMES", 0,'M',2200000,"Minnesota"));
        t.addPlayer(new Player("BORRE", 0,'A',4400000,"Sport Club"));
        t.addPlayer(new Player("LUCUMI", 0,'D',125000000,"Bologna"));
        t.addPlayer(new Player("VARGAS", 0,'P',540000,"Atlas"));
        
        try{
            t.defaultMarkedValue(1000000, 1000);
            fail("Did not throw exception");
        }
        catch(FifaException f){
            assertEquals(FifaException.IMPOSSIBLE,f.getMessage());
        }
    }
    
    @Test
    public void shouldThrowExceptionIfTeamHasNotPlayersInDefaultMarketValue(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        
        try { 
           int value=t.defaultMarkedValue(1000000, 1000);
           fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.IMPOSSIBLE,e.getMessage());
        }  
    }
    
    @Test
    public void shouldCalculateMarketValueExpectedMarketValue(){
        Team t = new Team("COLOMBIA",1620, 'K', "Lorenzo", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("L.DIAZ", 100,'A', 10000000,"Bayer"));
        t.addPlayer(new Player("JAMES", 60,'M', 30000000,"Minnesota"));
        t.addPlayer(new Player("BORRE", 40,'A', 50000000,"Sport Club"));
        int value = 0;
        try { 
           value=t.expectedMarketValue();
        } catch (FifaException e) {
            e.printStackTrace();
        }    
        assertEquals(24000000, value);
    }

   @Test
   public void shouldThrowExceptionExpectedMarketValueValueUnknowDefaultMarketValue() {
       Team t = new Team("COLOMBIA",1620, 'K', "Hernan", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("BOHORQUEZ", 100, 'E', null, "Nu Colombia"));
        t.addPlayer(new Player("LOPEZ", 60, 'M', 30000000, "Minnesota"));
        t.addPlayer(new Player("URIBE", 40, 'A', 50000000, "Sport Club"));
       try { 
           int value=t.expectedMarketValue();
           fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.VALUE_UNKNOWN, e.getMessage());
        }    
   }
   
   @Test
   public void shouldCalculateExpectedMarketValueWithoutAMin() {
       Team t = new Team("COLOMBIA",1620, 'K', "Hernan", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("BOHORQUEZ", null, 'E', 10000000, "Nu Colombia"));
        t.addPlayer(new Player("LOPEZ", 60, 'M', 30000000, "Minnesota"));
        t.addPlayer(new Player("URIBE", 40, 'A', 50000000, "Sport Club"));
        int value = 0;
        try { 
           value=t.expectedMarketValue(); // Calcula el valor cuando no hay un valor de minutos
           
        } catch (FifaException e) {
            e.printStackTrace();
        }    
        
        assertEquals(28666666, value); 
   }
   
   @Test
   public void shouldCalculateExpectedMarketValueWithoutTwoMins() {
       Team t = new Team("COLOMBIA",1620, 'K', "Hernan", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("BOHORQUEZ", 100, 'E', 10000000, "Nu Colombia"));
        t.addPlayer(new Player("LOPEZ", null, 'M', 30000000, "Minnesota"));
        t.addPlayer(new Player("URIBE", null, 'A', 50000000, "Sport Club"));
        int value = 0;
        try { 
           value=t.expectedMarketValue(); // Calcula el valor cuando no hay un valor de minutos
           
        } catch (FifaException e) {
            e.printStackTrace();
        }    
        
        assertEquals(30000000, value); 
   }
   
   @Test
   public void shouldCalculateExpected() {
       Team t = new Team("COLOMBIA",1620, 'K', "Hernan", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("BOHORQUEZ", 100, 'E', 10000000, "Nu Colombia"));
        t.addPlayer(new Player("LOPEZ", null, 'M', 30000000, "Minnesota"));
        t.addPlayer(new Player("URIBE", null, 'A', 50000000, "Sport Club"));
        int value = 0;
        try { 
           value=t.expectedMarketValue(); // Calcula el valor cuando no hay un valor de minutos
           
        } catch (FifaException e) {
            e.printStackTrace();
        }    
        
        assertEquals(30000000, value); 
   }
   
   @Test
   public void shouldThrowExceptionExpectedMarketValueImpossible() {
       Team t = new Team("COLOMBIA",1620, 'K', "Hernan", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("BOHORQUEZ", null, 'E', 10000000, "Nu Colombia"));
        t.addPlayer(new Player("LOPEZ", null, 'M', 30000000, "Minnesota"));
        t.addPlayer(new Player("URIBE", null, 'A', 50000000, "Sport Club"));
        
        int value = 0;
        try { 
           value=t.expectedMarketValue(); // Calcula el valor cuando no hay un valor de minutos
           
         fail("Did not throw exception");
        } catch (FifaException e) {
            assertEquals(FifaException.IMPOSSIBLE, e.getMessage());
        }    
   }
    /*
     * Team t = new Team("COLOMBIA",1620, 'K', "Hernan", "Amarill-Rojo-Azul");
        t.addPlayer(new Player("BOHORQUEZ", 100, 'E', 10000000, "Nu Colombia"));
        t.addPlayer(new Player("LOPEZ", 60, 'M', 30000000, "Minnesota"));
        t.addPlayer(new Player("URIBE", 40, 'A', 50000000, "Sport Club"));

     */
}